package manager;

import java.util.List;

public interface ManagerDAO {
	public List<Manager> ListManager();

	public Manager findManagerbyUsername(String u);
}
