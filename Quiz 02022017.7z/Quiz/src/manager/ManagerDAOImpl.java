package manager;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

//@Transactional
public class ManagerDAOImpl implements ManagerDAO {
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Manager> ListManager() {
		Session session = this.sessionFactory.getCurrentSession();

		@SuppressWarnings("unchecked")
		List<Manager> list = session.createQuery("from Manager").list();

		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Manager findManagerbyUsername(String u) {
		Session session = this.sessionFactory.getCurrentSession();
		List<Manager> m = new ArrayList<Manager>();
		m = session.createQuery("from Manager where UserName=:name").setParameter("name", u).list();
		if (m.size() > 0) {
			return m.get(0);
		} else {
			return null;
		}
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

}
