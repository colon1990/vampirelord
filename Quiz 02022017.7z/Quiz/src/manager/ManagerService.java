package manager;

import java.util.List;

public interface ManagerService {
	public List<Manager> ListManager();

	public Manager findManagerbyUserName(String u);

	public void insertManager(Manager c);

	public void updateManager(Manager c);

	public void deleteManager(int id);

	public Manager findbyId(int id);
}
