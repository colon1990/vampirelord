package quiz.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import quiz.entities.Answer;
import quiz.service.AnswerService;
import quiz.service.QuestionService;

@Controller
@RequestMapping(value = "/answer**")
public class AnswerController {

	@Autowired
	private AnswerService answerService;
	
	@Autowired
	private QuestionService questionService;

	
	@RequestMapping(method = RequestMethod.GET)
	public String index() {
		return "redirect:/answer/list.html";
	}
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(ModelMap modelMap) {
		modelMap.put("listAnswer", answerService.ListAnswer());
		return "admin.answer.list";
	}

	// ================================================================

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.put("answer", new Answer());
		modelMap.put("question", questionService.ListQuestion());
		return "admin.answer.add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "answer") Answer answer, ModelMap modelMap) {
		answerService.createAnswer(answer);
		return "redirect:/answer/list.html";
	}

	// ====================================================================

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.put("answer", answerService.findAnswerByID(id));
		modelMap.put("question", questionService.ListQuestion());
		return "admin.answer.edit";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "answer") Answer answer, ModelMap modelMap) {
		answerService.updateAnswer(answer);
		return "redirect:/answer/list.html";
	}

	// ================================================================

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") int id) {
		this.answerService.deleteAnswer(answerService.findAnswerByID(id));
		return "redirect:/answer/list.html";
	}

	// ================================================================
}
