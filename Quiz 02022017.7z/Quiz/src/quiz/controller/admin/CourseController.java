    package quiz.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import quiz.entities.Course;
import quiz.service.CourseService;



@Controller
@RequestMapping(value = "/course**")
public class CourseController {

	@Autowired
	private CourseService courseService;
	
	@RequestMapping(method = RequestMethod.GET)
	public String index() {
		return "redirect:/course/list.html";
	}
	
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(ModelMap modelMap) {
		modelMap.put("listCourses", courseService.ListCourses());
		return "admin.course.list";
	}
	
	//================================================================
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.put("course", new Course());
		return "admin.course.add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "course") Course courses, ModelMap modelMap) {
		courseService.createCourse(courses);
		return "redirect:/course/list.html";
	}
	
	//====================================================================
	
	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.put("course", courseService.findCourseByID(id));
		return "admin.course.edit";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "course") Course course, ModelMap modelMap) {
		courseService.updateCourse(course);
		return "redirect:/course/list.html";
	}
	//====================================================================
	
	
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") int id) {
		this.courseService.deleteCourse(courseService.findCourseByID(id));
		return "redirect:/course/list.html";
	}
	
	
}
