package quiz.controller.admin;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import quiz.entities.Exam;
import quiz.entities.Examitems;
import quiz.entities.Question;
import quiz.service.CourseService;
import quiz.service.ExamService;
import quiz.service.QuestionService;
import quiz.service.QuizService;

@Controller
@RequestMapping(value = "/exam**")
public class ExamController {

	@Autowired
	private ExamService examService;

	@Autowired
	private CourseService courseService;
	
	@Autowired
	private QuizService quizService;
	
	@Autowired
	private QuestionService questionService;

	@RequestMapping(method = RequestMethod.GET)
	public String index() {
		return "redirect:/exam/list.html";
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(ModelMap modelMap) {
		modelMap.put("listExam", examService.ListAllExam());
		return "admin.exam.list";
	}

	// ================================================================
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.put("exam", new Exam());
		modelMap.put("courses", courseService.ListCourses());
		return "admin.exam.add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "exam") Exam exam, ModelMap modelMap) {
		exam.getCourse();
		examService.createExam(exam);
		return "redirect:/exam/list.html";
	}

	// ====================================================================

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("exam", examService.findExamByID(id));
		modelMap.put("courses", courseService.ListCourses());
		return "admin.exam.edit";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "Exam") Exam exam, ModelMap modelMap) {
		examService.updateExam(exam);
		return "redirect:/exam/list.html";
	}

	// ====================================================================


	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") int id) {

		this.examService.deleteExam(examService.findExamByID(id));
		return "redirect:/exam/list.html";
	}
	// ====================================================================

		/** id = examID
		 * @return
		 */
	@RequestMapping(value = "/modify/{id}", method = RequestMethod.GET)
	public String modify(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		Exam exam = examService.findExamByID(id);

		List<Examitems> lei = quizService.loadExamItemByExamID(exam.getId());
		int actual_size = lei.size();

		int cid = exam.getCourse().getId();
		List<Question> lq = questionService.listQuestionByCourseID(cid);

		modelMap.put("exam", exam);
		modelMap.put("actual_size", actual_size);
		modelMap.put("lq", lq);

		return "admin.exam.modify";
	}
	//=============================================================================================	
	
	@RequestMapping(value = "/addQuestion", method = RequestMethod.GET)
	public String addQuestion(HttpServletRequest request,ModelMap modelMap) {
		String choice = request.getParameter("choice");
		String eid = request.getParameter("examid");
		Integer examid = Integer.parseInt(eid);
		Exam exam = examService.findExamByID(examid);
		if (choice.equals("manual")) {
			// list Lon
			List<Question> lqcid = questionService.listQuestionByCourseID(exam.getCourse().getId());
			List<Question> lqeid = questionService.listQuestionByExamID(examid);
			
			
			// tao list Intger , so sanh se de hon
			List<Integer> lqcidInteger = new ArrayList<>();
			for (Question question : lqcid) 
				lqcidInteger.add(question.getId());
			
			
			List<Integer> lqeidInteger = new ArrayList<>();
			for (Question question : lqeid) 
				lqeidInteger.add(question.getId());

			
			
//			System.out.println("=========================");
//			System.out.println(" List Question by course ID (Question Bank) = " +lqcid.size() );
//			System.out.print(   " List Question by course ID - Item  = ");
//			for (Question question : lqcid) 
//				System.out.print (question.getId() + " ");
//			
//			System.out.println("");
//			System.out.println(   " List Question by exam ID (Examitem) = " + lqeid.size() );
//			System.out.print(   " List Question by  exam ID - Item  = ");
//			for (Question question : lqeid) 
//				System.out.print (question.getId() + " ");
//			System.out.println("");
//			System.out.println("=========================");
			
			
			List<Integer> addQuestionInteger  = new ArrayList<>();
			for (int i = 0; i < lqcid.size(); i++) { // chay list lon
				if (lqeidInteger.contains(lqcidInteger.get(i))) { // neu list ei da chua thi ko lam gi ca
				}
				else { // neu ko chua thi add vao
					addQuestionInteger.add(lqcidInteger.get(i));
				}
			}
			
//			for (Integer integer : addQuestionInteger) {
//				System.out.println(integer);
//			}
			
			List<Question> listAddQuestion  = new ArrayList<>();
				for (int i = 0; i < addQuestionInteger.size(); i++) {
					listAddQuestion.add(questionService.findQuestionByID(addQuestionInteger.get(i)));
				}
			modelMap.put("listAddQuestion", listAddQuestion);
			modelMap.put("examid", examid);
			
			return "admin.exam.addEachQuestion";
		} else if (choice.equals("multiple")) {
			return "admin.exam.addMultipleQuestion";
		} else{
			return "admin.exam.addRandomQuestion";
		}

	}
	
	
	// ====================================================================
	/**
	 * @param examid
	 * @param id  == questionID
	 * @return
	 */
	@RequestMapping(value = "/addEachQuestion/{examid}/{id}", method = RequestMethod.GET)
	public String addManualQuestion( @PathVariable(value="examid")Integer examid,  @PathVariable(value="id")Integer id ) {
		examService.addQuestion(examid, id);
//		return "redirect:/exam/modify/" + examid +".html";
		return "admin.exam.addEachQuestion";
		
	}
	//======================================================================================
	@RequestMapping(value = "/addMultipleQuestion", method = RequestMethod.GET)
	public String addManualQuestion() {
		return "admin.exam.modify.addMultipleQuestion";
	}
	// ====================================================================	
	@RequestMapping(value = "/addRandomQuestion", method = RequestMethod.GET)
	public String addRandomQuestion(HttpServletRequest request) {
		
//		Integer number =Integer.parseInt( request.getParameter("number"));
		Integer examID = Integer.parseInt(request.getParameter("examID"));
		return "redirect:/exam/modify/"+ examID  + ".html";
//		return "redirect:/exam/modify" + eid + ".html";
	}

	
	
	
	
	/**
	 * @param id == qID
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/removeQuestionFromExam/{examid}/{qid}", method = RequestMethod.GET)
	public String removeQuestionFromExam(@PathVariable(value = "examid") Integer examid,@PathVariable(value = "qid") Integer qid,ModelMap modelMap){
		System.out.println("examid = " + examid);
		System.out.println("qid = " + qid);
		
		examService.removeQuestionFromExam(examid, qid);
		return "redirect:/questionquestion/ListByExamID/"+examid+".html";
	}
	
}
