package quiz.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import quiz.entities.Question;
import quiz.service.AnswerService;
import quiz.service.CourseService;
import quiz.service.QuestionService;

/**
 * @author dhonghai
 *
 */
@Controller
@RequestMapping(value = "/question**")
public class QuestionController {

	@Autowired
	private QuestionService questionService;

	@Autowired
	private CourseService courseService;

	@Autowired
	private AnswerService answerService;

	
	@RequestMapping(method = RequestMethod.GET)
	public String index() {
		return "admin.question.list";
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(ModelMap modelMap) {
		modelMap.put("listQuestion", questionService.ListQuestion());
		return "admin.question.list";
	}

	// ================================================================
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.put("question", new Question());
		modelMap.put("courses", courseService.ListCourses());
		modelMap.put("questionlevel", questionService.ListAllQuestionLevel());
		return "admin.question.add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "question") Question question, ModelMap modelMap) {
		questionService.createQuestion(question);
		return "redirect:/question/list.html";
	}
	// ====================================================================

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	private String delete(@PathVariable(value = "id") int id) {
		this.questionService.deleteQuestion(questionService.findQuestionByID(id));
		return "redirect:/question/list.html";
	}

	// ====================================================================

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.put("question", questionService.findQuestionByID(id));
		modelMap.put("courses", courseService.ListCourses());
		modelMap.put("questionlevel", questionService.ListAllQuestionLevel());
		return "admin.question.edit";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "Question") Question Question, ModelMap modelMap) {
		questionService.updateQuestion(Question);
		return "redirect:/question/list.html";
	}

	// ====================================================================

	/**
	 * @param id
	 *            == question id
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/modifyAnswer/{id}", method = RequestMethod.GET)
	public String modifyAnswer(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("question", questionService.findQuestionByID(id));
		modelMap.put("answer", answerService.findAnswerByQuesntionID(id));
		return "admin.question.modifyAnswer";
	}

	/**
	 * @param id == courseID
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/ListByCourseID/{id}", method = RequestMethod.GET)
	public String ListQuestionByCourseID(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("listQuestion", questionService.listQuestionByCourseID(id));
		return "admin.question.listQuestionByCourseID";
	}
	
	

	/**
	 * @param id == examID
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/ListByExamID/{id}", method = RequestMethod.GET)
	public String ListQuestionByExamID(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("listQuestion", questionService.listQuestionByExamID(id));
		modelMap.put("examid", id);
		return "admin.question.listQuestionByExamID";
	}
}
