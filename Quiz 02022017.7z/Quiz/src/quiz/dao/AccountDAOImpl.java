package quiz.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import quiz.entities.UserRole;
import quiz.entities.Users;

@Repository(value = "accountDAO")
public class AccountDAOImpl implements AccountDAO {
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<Users> ListAccount() {
//		try {
//			if (!sessionFactory.getCurrentSession().getTransaction().isActive())
//				sessionFactory.getCurrentSession().getTransaction().begin();
			return sessionFactory.getCurrentSession().createQuery("from Users").list();
//		} catch (RuntimeException re) {
//			return null;
//		}
	}

	@Override
	public void createAccount(Users user) {
//		try {
//			if (!sessionFactory.getCurrentSession().getTransaction().isActive())
//				sessionFactory.getCurrentSession().getTransaction().begin();
			sessionFactory.getCurrentSession().persist(user);
//			sessionFactory.getCurrentSession().getTransaction().commit();
//		} catch (RuntimeException re) {
//			sessionFactory.getCurrentSession().getTransaction().rollback();
//			throw re;
//		}
	}

	@Override
	public void deleteAccount(Users user) {
//		try {
//			if (!sessionFactory.getCurrentSession().getTransaction().isActive())
//				sessionFactory.getCurrentSession().getTransaction().begin();
			sessionFactory.getCurrentSession().delete(user);
//			sessionFactory.getCurrentSession().getTransaction().commit();
//		} catch (RuntimeException re) {
//			sessionFactory.getCurrentSession().getTransaction().rollback();
//			throw re;
//		}
	}

	@Override
	public void updateAccount(Users user) {
//		try {
//			if (!sessionFactory.getCurrentSession().getTransaction().isActive())
//				sessionFactory.getCurrentSession().getTransaction().begin();
			sessionFactory.getCurrentSession().saveOrUpdate(user);
//			sessionFactory.getCurrentSession().getTransaction().commit();
//		} catch (RuntimeException re) {
//			sessionFactory.getCurrentSession().getTransaction().rollback();
//			throw re;
//		}

	}

	@Override
	public Users findAccountByID(int id) {
		try {
			if (!sessionFactory.getCurrentSession().getTransaction().isActive())
				sessionFactory.getCurrentSession().getTransaction().begin();
			return (Users) sessionFactory.getCurrentSession().get(Users.class, id);
		} catch (RuntimeException re) {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserRole> listRole() {
		return sessionFactory.getCurrentSession().createCriteria(UserRole.class).list();
	}

	@Override
	public Integer findIDByUsername(String username) {
		Users user = (Users) sessionFactory.getCurrentSession()
				.createCriteria(Users.class)
				.add(Restrictions.eq("username", username))
				.uniqueResult();
		return user.getId();
	}

	/* (non-Javadoc)
	 * chua tinh den truong hop truong username luc login
	 * @see quiz.dao.AccountDAO#loadUserByUsername(java.lang.String)
	 */
	@Override
	public Users loadUserByUsername(String username) {
		Users user = (Users) sessionFactory.getCurrentSession()
				.createCriteria(Users.class)
				.add(Restrictions.eq("username", username))
				.uniqueResult();
		
		return user;
	}

}
