package quiz.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import quiz.entities.Answer;
import quiz.entities.Question;

@Repository(value = "answerDAO")
public class AnswerDAOImpl implements AnswerDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<Answer> ListAnswer() {
		return sessionFactory.getCurrentSession().createQuery("from Answer").list();
	}

	@Override
	public void createAnswer(Answer a) {
		sessionFactory.getCurrentSession().persist(a);
	}

	@Override
	public void updateAnswer(Answer a) {
		sessionFactory.getCurrentSession().merge(a);
	}

	@Override
	public void deleteAnswer(Answer a) {
		sessionFactory.getCurrentSession().delete(a);
	}

	@Override
	public Answer findAnswerByID(int id) {
		return (Answer) sessionFactory.getCurrentSession().get(Answer.class, id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Answer> findAnswerByQuesntionID(Integer qid) {
		return   sessionFactory.getCurrentSession()
				.createCriteria(Answer.class)
				.add(Restrictions
				.eq("question.id", qid))
				.list();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Answer> ListAnswerByQuesntionID(Question q) {
		return   sessionFactory.getCurrentSession()
				.createCriteria(Answer.class)
				.add(Restrictions
				.eq("question.id",q.getId()))
				.list();
	}

	@Override
	public Answer findTrueAnswerByQuestionID(Integer qid) {
		return   (Answer) sessionFactory.getCurrentSession()
				.createSQLQuery("select * from quiz2.answer where QuestionID = :qid and TrueFalseAnswer = 1")
				.addEntity(Answer.class)
				.setParameter("qid", qid)
				.uniqueResult();
	}

}
