package quiz.dao;

import java.util.List;

import quiz.entities.Course;

public interface CourseDAO {
	public List<Course> ListCourses();

	public void createCourse(Course c);

	public void updateCourse(Course c);

	public void deleteCourse(Course c);

	public Course findCourseByID(int i);
}
