package quiz.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import quiz.entities.Course;

@Repository(value = "courseDAO")
public class CourseDAOImpl implements CourseDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@SuppressWarnings("unchecked")
	public List<Course> ListCourses() {
		return sessionFactory.getCurrentSession().createCriteria(Course.class).list();
	}

	@Override
	public void createCourse(Course c) {
		sessionFactory.getCurrentSession().persist(c);
	}

	@Override
	public void updateCourse(Course c) {
		sessionFactory.getCurrentSession().merge(c);

	}

	@Override
	public void deleteCourse(Course c) {
		sessionFactory.getCurrentSession().delete(c);
	}

	@Override
	public Course findCourseByID(int id) {
		return (Course) sessionFactory.getCurrentSession().get(Course.class, id);
	}

}
