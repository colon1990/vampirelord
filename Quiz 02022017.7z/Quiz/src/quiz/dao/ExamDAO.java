package quiz.dao;

import java.util.List;

import quiz.entities.Exam;

public interface ExamDAO {

	public List<Exam> ListAllExam();

	public void createExam(Exam exam);

	public void updateExam(Exam exam);

	public void deleteExam(Exam exam);

	public Exam findExamByID(int id);

	public void addTenRandomQuestion(Integer exam);

	public void addQuestion(Integer examid, Integer questionid);

	public void removeQuestionFromExam(Integer examID, Integer questionID);

}
