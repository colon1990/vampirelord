package quiz.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import quiz.entities.Exam;
import quiz.entities.Examitems;
import quiz.entities.Question;

@Repository(value = "examDAO")
public class ExamDAOImpl implements ExamDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<Exam> ListAllExam() {
		return sessionFactory.getCurrentSession().createCriteria(Exam.class).list();
	}

	@Override
	public void createExam(Exam exam) {
		sessionFactory.getCurrentSession().persist(exam);
	}

	@Override
	public void updateExam(Exam exam) {
		sessionFactory.getCurrentSession().merge(exam);
	}

	@Override
	public void deleteExam(Exam exam) {
		sessionFactory.getCurrentSession().delete(exam);
	}

	@Override
	public Exam findExamByID(int id) {
		return (Exam) sessionFactory.getCurrentSession().get(Exam.class, id);
	}

	/*
	 * @see quiz.dao.ExamDAO#createRandomExam(quiz.entities.Exam)
	 * 
	 * @asdasd
	 */
	@Override
	public void addTenRandomQuestion(Integer examid) {

	}

	@Override
	public void removeQuestionFromExam(Integer examID, Integer questionID) {

		Examitems ei = (Examitems) sessionFactory.getCurrentSession().
		// createSQLQuery( "DELETE FROM `quiz2`.`examitems` WHERE `ExamID` = "+
		// examID + " AND `QuestionID` = "+ questionID ) ;
		// delete(new Examitems(exam, question));

		// createSQLQuery("Select * from `quiz2`.`examitems` WHERE
		// `ExamID`=:examID AND `QuestionID`=:questionID")
		// .addEntity(Examitems.class)
		// .setParameter("examID", examID).setParameter("questionID",
		// questionID);

				createCriteria(Examitems.class).add(Restrictions.eq("exam.id", examID))
				.add(Restrictions.eq("question.id", questionID)).uniqueResult();

		System.out.println("EI vua moi bam vao = " + ei.getId());
		sessionFactory.getCurrentSession().delete(ei);
		System.out.println("=======================");
		System.out.println("remove done ");
		System.out.println("=======================");

		// sessionFactory.getCurrentSession().delete(arg0);
		// DELETE FROM `quiz2`.`examitems` WHERE `ExamID` = 4 AND `QuestionID`=
		// 15
	}

	@Override
	public void addQuestion(Integer examid, Integer questionid) {
		Exam exam = findExamByID(examid);
		Question question = (Question) sessionFactory.getCurrentSession().get(Question.class, questionid);
		Examitems ei = new Examitems(exam, question);
		sessionFactory.getCurrentSession().persist(ei);
		System.out.println("add exam items done");
	}

}
