package quiz.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import quiz.entities.Question;
import quiz.entities.Questionlevel;

@Repository(value = "questionDAO")
public class QuestionDAOImpl implements QuestionDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<Question> ListQuestion() {
		
		return sessionFactory.getCurrentSession().createQuery("from Question").list();
//		return sessionFactory.getCurrentSession().createCriteria(Question.class).list();
	}

	@Override
	public void createQuestion(Question q) {
		sessionFactory.getCurrentSession().persist(q);
	}

	@Override
	public void deleteQuestion(Question q) {
		sessionFactory.getCurrentSession().delete(q);

	}

	@Override
	public Question findQuestionByID(Integer id) {
		return (Question) sessionFactory.getCurrentSession().get(Question.class, id);
	}

	@Override
	public void updateQuestion(Question q) {
		sessionFactory.getCurrentSession().saveOrUpdate(q);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Questionlevel> ListAllQuestionLevel() {
		return sessionFactory.getCurrentSession().createQuery("from Questionlevel").list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Question> listQuestionByCourseID(int cid) {
		return sessionFactory.getCurrentSession().
				createCriteria(Question.class).
				add(Restrictions.eq("course.id", cid)).
				list();
				
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Question> listQuestionByExamID(int eid) {
		List<Integer> ls = sessionFactory.getCurrentSession().
				createSQLQuery("Select QuestionID from Examitems where ExamID =:examid ").
				setParameter("examid", eid).
				list();
		
		List<Question> lq = new ArrayList<>();
		for (Integer integer : ls) {
			lq.add(findQuestionByID(integer));
		}
		return lq;
	}

}
