package quiz.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import quiz.entities.Exam;
import quiz.entities.Examitems;
import quiz.entities.Question;
import quiz.entities.Result;

@Repository(value = "quizDAO")
public class QuizDAOImpl implements QuizDAO {
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<Question> generateQuiz() {
		
		/*
		int size = sessionFactory.getCurrentSession().createCriteria(Question.class).list().size();
		List<Question> listq = new ArrayList<>();


//		ArrayList<Integer> numbers = new ArrayList<Integer>();
//		Random randomGenerator = new Random();
//		while (numbers.size() < size) {
//
//			int random = randomGenerator.nextInt(size);
//			if (!numbers.contains(random)) {
//				numbers.add(random);
//			}
//		}

		for (int i = 0; i < 10; i++) {
			listq.add((Question) sessionFactory.getCurrentSession().get(Question.class, i));
		}*/
		
//		for (int i = 0; i < 12; i++) {
//			System.out.println(result.get(i).getAnswers().size());
//		}
		
		
		return sessionFactory.getCurrentSession().createCriteria(Question.class).list();
	}

	
	
	
	@SuppressWarnings("unchecked")
	public List<Result> listResultByUserID(int id){
		
		return sessionFactory.getCurrentSession()
				.createCriteria(Result.class)
				.add(Restrictions.eq("UserID", id))
				.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Exam> ListAllExam() {
		return sessionFactory.getCurrentSession()
				.createCriteria(Exam.class)
				.list();
	}




	@SuppressWarnings("unchecked")
	@Override
	public List<Exam> ListExamByCoursesID(Integer id) {
		return sessionFactory.getCurrentSession()
				.createCriteria(Exam.class)
				.add(Restrictions.eq("course.id", id))
				.list();
	}




	@SuppressWarnings("unchecked")
	@Override
	public List<Examitems> loadExamItemByExamID(Integer id) {
		return sessionFactory.getCurrentSession()
				.createCriteria(Examitems.class)
				.add(Restrictions.eq("exam.id", id))
				.list();
	}




	@SuppressWarnings("unchecked")
	@Override
	public List<Question> loadQuestionFromExamID(Integer id) {
		
		List<Question> listQ = new ArrayList<>();
		List<Examitems> listEI = new ArrayList<>();
		listEI = sessionFactory.getCurrentSession().createQuery(" from Examitems  where exam.id=:examid ").setParameter("examid", id).list();
		for (Examitems examitems : listEI) {
			listQ.add(examitems.getQuestion());
		}
		return listQ;
	}
}
