package quiz.dao;

import java.util.List;

import quiz.entities.Result;
import quiz.entities.Trackingresult;

public interface ResultDAO {

	public List<Result> listAllResult();

	public List<Result> ListAllResultByUserID(int id);

	public void createResult(Result result);

	public List<Trackingresult> LoadTrackingResultByResultID(Integer id);

	public void createTrackingResult(Trackingresult tr);

	public Result LoadResultByResultID(int rid);

}
