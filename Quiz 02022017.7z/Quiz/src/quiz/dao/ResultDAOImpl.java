package quiz.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import quiz.entities.Result;
import quiz.entities.Trackingresult;

@Repository(value = "resultDAO")
public class ResultDAOImpl implements ResultDAO {
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<Result> listAllResult() {
		return sessionFactory.getCurrentSession().createQuery("from Result").list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Result> ListAllResultByUserID(int id) {
		// return sessionFactory.getCurrentSession()
		// .createQuery("from Result where users.id := userid ")
		// .setParameter("userid", id)
		// .list();

		return sessionFactory.getCurrentSession().createCriteria(Result.class).add(Restrictions.eq("users.id", id))
				.list();
	}

	@Override
	public void createResult(Result result) {
		sessionFactory.getCurrentSession().persist(result);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Trackingresult> LoadTrackingResultByResultID(Integer id) {
		return sessionFactory.getCurrentSession().
				createCriteria(Trackingresult.class).
				add(Restrictions.eq("result.id", id)).
				list();
	}

	@Override
	public void createTrackingResult(Trackingresult tr) {
		sessionFactory.getCurrentSession().persist(tr);
	}

	@Override
	public Result LoadResultByResultID(int rid) {
		return  (Result) sessionFactory.getCurrentSession().
				createCriteria(Result.class).
				add(Restrictions.eq("id", rid)).
				uniqueResult();
	}
}
