package quiz.service;

import java.util.List;

import quiz.entities.UserRole;
import quiz.entities.Users;

public interface AccountService {

	public List<Users> ListAccount();

	public void createAccount(Users user);

	public void deleteAccount(Users id);

	public void updateAccount(Users user);

	public Users findAccountByID(int id);
	
	public Integer findIDByUsername(String username);
	
	public Users loadUserByUsername(String username);


	public List<UserRole> listRole();
}
