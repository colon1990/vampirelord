package quiz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import quiz.dao.AccountDAO;
import quiz.dao.QuizDAO;
import quiz.entities.UserRole;
import quiz.entities.Users;

@Service(value = "accountService")
@Transactional
public class AccountServiceImpl implements AccountService {
	@Autowired
	private AccountDAO accountDAO;

	@Override
	public List<Users> ListAccount() {
		return accountDAO.ListAccount();
	}

	@Override
	public void createAccount(Users user) {
		accountDAO.createAccount(user);

	}

	@Override
	public void deleteAccount(Users id) {
		accountDAO.deleteAccount(id);

	}

	@Override
	public void updateAccount(Users user) {
		accountDAO.updateAccount(user);
	}

	@Override
	public Users findAccountByID(int id) {

		return accountDAO.findAccountByID(id);
	}

	@Override
	public List<UserRole> listRole() {

		return accountDAO.listRole();
	}

	@Override
	public Integer findIDByUsername(String username) {
		return accountDAO.findIDByUsername(username);
	}

	@Override
	public Users loadUserByUsername(String username) {
		return accountDAO.loadUserByUsername(username);
	}

}
