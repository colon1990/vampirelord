package quiz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import quiz.dao.AnswerDAO;
import quiz.entities.Answer;
import quiz.entities.Question;

@Service(value = "answerService")
@Transactional
public class AnswerServiceImpl implements AnswerService {
	@Autowired
	private AnswerDAO answerDAO;

	@Override
	public List<Answer> ListAnswer() {
		return answerDAO.ListAnswer();
	}

	@Override
	public void createAnswer(Answer a) {
		answerDAO.createAnswer(a);
	}

	@Override
	public void updateAnswer(Answer a) {
		answerDAO.updateAnswer(a);
	}

	@Override
	public void deleteAnswer(Answer a) {
		answerDAO.deleteAnswer(a);
	}

	@Override
	public Answer findAnswerByID(int id) {
		return answerDAO.findAnswerByID(id);
	}

	@Override
	public List<Answer> findAnswerByQuesntionID(Integer qid) {
		return answerDAO.findAnswerByQuesntionID(qid);
	}

	@Override
	public List<Answer> ListAnswerByQuesntionID(Question q) {
		return answerDAO.ListAnswerByQuesntionID(q);
	}

	@Override
	public Answer findTrueAnswerByQuestionID(Integer qid) {
		return answerDAO.findTrueAnswerByQuestionID(qid);
	}

}
