package quiz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import quiz.dao.CourseDAO;
import quiz.entities.Course;

@Service(value = "courseService")
@Transactional
public class CourseServiceImpl implements CourseService {
	@Autowired
	private CourseDAO courseDAO ;

	@Override
	public List<Course> ListCourses() {
		return courseDAO.ListCourses();
	}

	@Override
	public void createCourse(Course c) {
		courseDAO.createCourse(c);
	}

	@Override
	public void updateCourse(Course c) {
		courseDAO.updateCourse(c);
	}

	@Override
	public void deleteCourse(Course c) {
		courseDAO.deleteCourse(c);
	}

	@Override
	public Course findCourseByID(int i) {
		return courseDAO.findCourseByID(i);
	}

}
