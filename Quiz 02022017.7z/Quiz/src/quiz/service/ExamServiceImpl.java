package quiz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import quiz.dao.ExamDAO;
import quiz.entities.Exam;

@Service(value = "examService")
@Transactional
public class ExamServiceImpl implements ExamService {

	@Autowired
	private ExamDAO examDAO;

	@Override
	public List<Exam> ListAllExam() {
		return examDAO.ListAllExam();
	}

	@Override
	public void createExam(Exam exam) {
		examDAO.createExam(exam);

	}

	@Override
	public void updateExam(Exam exam) {
		examDAO.updateExam(exam);

	}

	@Override
	public void deleteExam(Exam exam) {
		examDAO.deleteExam(exam);
	}

	@Override
	public Exam findExamByID(int id) {
		return examDAO.findExamByID(id);
	}

	@Override
	public void addTenRandomQuestion(Integer exam) {
		examDAO.addTenRandomQuestion(exam);
	}

	@Override
	public void removeQuestionFromExam(Integer examID, Integer questionID) {
		examDAO.removeQuestionFromExam(examID, questionID);
	}

	@Override
	public void addQuestion(Integer examid, Integer questionid) {
		examDAO.addQuestion(examid, questionid);
	}

}
