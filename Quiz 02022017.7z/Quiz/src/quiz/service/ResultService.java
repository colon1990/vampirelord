package quiz.service;

import java.util.List;

import quiz.entities.Result;
import quiz.entities.Trackingresult;

public interface ResultService {

	public List<Result> listAllResult();

	public List<Result> ListAllResultByUserID(int id);

	public void createResult(Result result);

	public List<Trackingresult> LoadTrackingResultByResultID(Integer id);

	public void createTrackingResult(Trackingresult tr);
	
	public Result LoadResultByResultID(int rid);
}
