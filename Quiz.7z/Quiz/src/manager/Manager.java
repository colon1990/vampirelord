package manager;

public class Manager {

}
