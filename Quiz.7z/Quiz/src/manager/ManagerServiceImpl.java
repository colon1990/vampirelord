package manager;

import java.util.List;

//@Service
//@Transactional
public class ManagerServiceImpl implements ManagerService {
//	@Autowired
	ManagerDAO managerDAO;

	@Override
	public List<Manager> ListManager() {

		return null;
	}

	
	
	@Override
	public Manager findManagerbyUserName(String u) {
		return this.managerDAO.findManagerbyUsername(u);
	}

	public ManagerDAO getManagerDAO() {
		return managerDAO;
	}

	public void setManagerDAO(ManagerDAO managerDAO) {
		this.managerDAO = managerDAO;
	}

	@Override
	public void insertManager(Manager c) {

	}

	@Override
	public void updateManager(Manager c) {

	}

	@Override
	public void deleteManager(int id) {

	}

	@Override
	public Manager findbyId(int id) {

		return null;
	}

}
