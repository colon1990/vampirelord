package quiz.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import quiz.entities.Users;
import quiz.service.AccountService;

@Controller
@RequestMapping(value = "/account**")
public class AccountController {

	@Autowired
	private AccountService accountService;

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.put("listAccount", accountService.ListAccount());
		return "listAccount";
	}

	@RequestMapping(value = "/listAccount", method = RequestMethod.GET)
	public String list(ModelMap modelMap) {
		modelMap.put("listAccount", accountService.ListAccount());
//		return "Account/listAccount";
		return "admin.account.list";
	}

	// ================================================================
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.put("account", new Users());
		modelMap.put("roles", accountService.listRole()); // load role
		return "admin.account.add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "Account") Users user, ModelMap modelMap) {
		accountService.createAccount(user);
		return "redirect:/account/list.html";
	}
	// ====================================================================

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	private String delete(@PathVariable(value = "id") int id) {
		this.accountService.deleteAccount(accountService.findAccountByID(id));
		return "redirect:/account/listAccount.html";
	}

	// ====================================================================

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.put("account", accountService.findAccountByID(id));
		modelMap.put("roles", accountService.listRole()); // load role
		return "admin.account.edit";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "Account") Users user, ModelMap modelMap) {

		accountService.updateAccount(user);
		return "redirect:/account/listAccount.html";
	}

	// ====================================================================

}
