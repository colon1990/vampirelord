    package quiz.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import quiz.entities.Courses;
import quiz.service.CoursesService;



@Controller
@RequestMapping(value = "/courses**")
public class CoursesController {

	@Autowired
	private CoursesService CoursesService;
	
	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.put("listCourses", CoursesService.ListCourses());
		return "Course/listCourses";
	}
	
	
	@RequestMapping(value = "/listCourses", method = RequestMethod.GET)
	public String list(ModelMap modelMap) {
		modelMap.put("listCourses", CoursesService.ListCourses());
		return "Course/listCourses";
	}
	
	//================================================================
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.put("course", new Courses());
		return "Course/addCourses";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "course") Courses courses, ModelMap modelMap) {
		CoursesService.createCourses(courses);
		return "redirect:/courses/listCourses.html";
	}
	
	//====================================================================
	
	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.put("courses", CoursesService.findCoursesByID(id));
		return "Course/editCourses";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "Courses") Courses Courses, ModelMap modelMap) {
		CoursesService.updateCourses(Courses);
		return "redirect:/courses/listCourses.html";
	}
	//====================================================================
	
	
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	private String delete(@PathVariable(value = "id") int id) {
		this.CoursesService.deleteCourses(CoursesService.findCoursesByID(id));
		return "redirect:/courses/listCourses.html";
	}
	
	
}
