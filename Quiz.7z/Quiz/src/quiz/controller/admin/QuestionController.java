package quiz.controller.admin;

import java.sql.Date;
import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import quiz.entities.Question;
import quiz.service.AnswerService;
import quiz.service.CoursesService;
import quiz.service.QuestionService;

/**
 * @author dhonghai
 *
 */
@Controller
@RequestMapping(value = "/question**")
public class QuestionController {

	@Autowired
	private QuestionService questionService;

	@Autowired
	private CoursesService coursesService;

	@Autowired
	private AnswerService answerService;

	
	@RequestMapping(method = RequestMethod.GET)
	public String index() {
//		modelMap.put("listQuestion", questionService.ListQuestion());
		return "Question/listQuestion";
	}

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}

	@RequestMapping(value = "/listQuestion", method = RequestMethod.GET)
	public String list(ModelMap modelMap) {
		modelMap.put("listQuestion", questionService.ListQuestion());
		return "Question/listQuestion";
	}

	// ================================================================
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.put("question", new Question());
		modelMap.put("courses", coursesService.ListCourses());
		modelMap.put("questionlevel", questionService.ListAllQuestionLevel());
		return "addQuestion";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "question") Question question, ModelMap modelMap) {
		questionService.createQuestion(question);
		return "redirect:/question/listQuestion.html";
	}
	// ====================================================================

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	private String delete(@PathVariable(value = "id") int id) {
		this.questionService.deleteQuestion(questionService.findQuestionByID(id));
		return "redirect:/question/listQuestion.html";
	}

	// ====================================================================

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.put("question", questionService.findQuestionByID(id));
		modelMap.put("courses", coursesService.ListCourses());
		modelMap.put("questionlevel", questionService.ListAllQuestionLevel());
		return "Question/editQuestion";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "Question") Question Question, ModelMap modelMap) {
		questionService.updateQuestion(Question);
		return "redirect:/question/listQuestion.html";
	}

	// ====================================================================

	/**
	 * @param id
	 *            == question id
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/modifyAnswer/{id}", method = RequestMethod.GET)
	public String modifyAnswer(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("question", questionService.findQuestionByID(id));
		modelMap.put("answer", answerService.findAnswerByQuesntionID(id));
		return "Question/modifyAnswer";
	}

	/**
	 * @param id == courseID
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/ListByCourseID/{id}", method = RequestMethod.GET)
	public String ListQuestionByCourseID(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("listQuestion", questionService.listQuestionByCourseID(id));
		return "Question/listQuestionByCourseID";
	}
	
	

	/**
	 * @param id == examID
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/ListByExamID/{id}", method = RequestMethod.GET)
	public String ListQuestionByExamID(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("listQuestion", questionService.listQuestionByExamID(id));
		modelMap.put("examid", id);
		return "Question/listQuestionByExamID";
	}
}
