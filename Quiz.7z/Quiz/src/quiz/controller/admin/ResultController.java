package quiz.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import quiz.service.AccountService;
import quiz.service.ResultService;

@Controller
@RequestMapping(value = "/result**")
public class ResultController {

	@Autowired
	private ResultService resultService;

	@Autowired
	private AccountService accountService;

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.put("listResult", resultService.listAllResult());
		return "listResult";
	}

	@RequestMapping(value = "/listResult", method = RequestMethod.GET)
	public String list(ModelMap modelMap) {
		modelMap.put("listResult", resultService.listAllResult());
		return "Result/listResult";
	}

	/**
	 * @param id
	 *            = userID
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/listResultByUser", method = RequestMethod.GET)
	public String listResultByUserID( ModelMap modelMap) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			UserDetails userDetail = (UserDetails) auth.getPrincipal();
			Integer userID = accountService.findIDByUsername(userDetail.getUsername());
			modelMap.put("listResultByUser", resultService.ListAllResultByUserID(userID));
		}
		return "Result/listResultByUser";
	}
	
	

}
