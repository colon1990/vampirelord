 package quiz.controller.user;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import quiz.entities.Answer;
import quiz.entities.Exam;
import quiz.entities.Question;
import quiz.entities.Result;
import quiz.entities.Trackingresult;
import quiz.model.QuizModelBegin;
import quiz.service.AccountService;
import quiz.service.AnswerService;
import quiz.service.CoursesService;
import quiz.service.ExamService;
import quiz.service.QuestionService;
import quiz.service.QuizService;
import quiz.service.ResultService;

/**
 * @author dhonghai
 *
 */
@Controller
@RequestMapping(value = "/quiz**")
public class QuizController {

	@Autowired
	private QuizService quizService;

	@Autowired
	private CoursesService coursesService;

	@Autowired
	private ExamService examService;

	@Autowired
	private ResultService resultService;

	@Autowired
	private AccountService accountService;
	
	@Autowired
	private AnswerService answerService;

	@Autowired
	private QuestionService questionService;

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.put("examCourses", coursesService.ListCourses());
		return "examCourses";
	}

	// ================================================================
	@RequestMapping(value = "chooseCourses", method = RequestMethod.GET)
	public String chooseCourses(ModelMap modelMap) {
		modelMap.put("listCourses", coursesService.ListCourses());
		return "chooseCourses";
	}

	// nhan vao CourseID choose Exam --> button Do exam
	// nhan vao Username -- > userid -- > load result cua UserID

	@RequestMapping(value = "chooseExam/{id}", method = RequestMethod.GET)
	public String chooseExam(@PathVariable(value = "id") Integer id, Exam exam, ModelMap modelMap) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			UserDetails userDetail = (UserDetails) auth.getPrincipal();
			modelMap.put("username", userDetail.getUsername());
			// modelMap.put("courseID",id);
			modelMap.put("course", coursesService.findCoursesByID(id));
			Integer userID = accountService.findIDByUsername(userDetail.getUsername());
			modelMap.put("userID", userID);
			modelMap.put("listResultByUserID", resultService.ListAllResultByUserID(userID.intValue()));
			modelMap.put("listExamByCoursesID", quizService.ListExamByCoursesID(id));
		}
		return "chooseExam";
	}

	// ================================================================
	
	
	/*
	 * Input : examID --> function( examID) ---> List<Examitems>
	 * Examitems (Exam exam, Question question) {
	 * 	Exam-->examID
	 * 	Question --> questionID ,questionDetails
	 *           --> Set<Answer> answers => answer.ID
	 *           							answer.answerDetail
	 *  									answer.trueFalseAnswer
	 * 
	 *  
	 */		
	
	@RequestMapping(value = "doQuiz/{id}", method = RequestMethod.GET)
	public String chooseExam(  @PathVariable(value = "id") Integer id, ModelMap modelMap) {
		
		//load List Question from ExamID
		List<Question> listQuestion = quizService.loadQuestionFromExamID(id);
//		List<Answer> listAnswer = new ArrayList<Answer>();
		
		List<QuizModelBegin> listQuizModelBegin = new ArrayList<QuizModelBegin>() ;
		
		for (int i = 0; i < listQuestion.size(); i++) {
			listQuizModelBegin.add(
					new QuizModelBegin(listQuestion.get(i), answerService.ListAnswerByQuesntionID(listQuestion.get(i))));
		}

		
		modelMap.put("listQuestion",listQuestion);
		modelMap.put("listQuizModelBegin", listQuizModelBegin);
		
		modelMap.put("examid", id);
		modelMap.put("number", listQuizModelBegin.size());
		
		return "doQuiz";
	}
	//===============================================================
	
	
	/*
	 * Output
	 * examID,
	 * username  hoac userID
	 * questionID, choiceAnswerID,choice
	 * 
	 * -->add 1 record trong table Result
	 * 		--> Result result = New Result();
	 * 				result.setExamID();result.setUsers();
	 * 				result.setScore(); result.setStatus() 
	 * User = abcService.findUserByUsername(String username);
	 * score = examID->Exam--> rightAnswer/numberOfQuestion *80 , if> 80% pass else fail  
	 */
	
	
	@RequestMapping(value = "doQuiz", method = RequestMethod.POST)
	public String doQuiz(
			@RequestParam(value = "examid") Integer examid,
			@RequestParam(value = "number") Integer number,
			HttpServletRequest request) {

		// get username
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetail = (UserDetails) auth.getPrincipal();
		
		// Parameter list
		Integer qID ;
		Integer cID ;
		int score =0;
		int trueAnswer;
		double ratio = 0;
		String pf = "" ; 
		int status = 0;
//		int result[][] ;
		
		
		
		System.out.println("======================================");
		System.out.println(number.intValue());
		for (int i = 0; i <  number.intValue(); i++) {
			System.out.println("i = " + i);
			qID = Integer.parseInt(request.getParameter("question_" + i));
			System.out.println("Question ID = " + qID);
			
			if (request.getParameter("answerid_" + i) == null) {
				cID = 0;
			} else {
				cID = Integer.parseInt(request.getParameter("answerid_" + i));
			}
			System.out.println("Choice ID = " + cID);
			System.out.println("======================================");
			
			trueAnswer = answerService.findTrueAnswerByQuestionID(qID).getId();
			if (trueAnswer ==  cID)
				score ++;
			
			System.out.println("Score = " + score);
			}
		
		ratio = (score * 100 / number);
		
		if (ratio > 70){
			pf = "passed";
			status = 1 ;
		}else{
			pf = "failed";}
		
		System.out.println("Ratio = " + ratio);
		System.out.println("Result = " + pf);
		
		
		
		
		
	
		
		
	
		
		
		
		//=============================	
//		public Result(Exam exam, Users users, int score, int status) 
		Result result = new Result();
		result.setExam(examService.findExamByID(examid));
		result.setUsers(accountService.findAccountByID(accountService.findIDByUsername(userDetail.getUsername())));
		result.setScore(score);
		result.setStatus(status);
		resultService.createResult(result);
		
		//=============================	
		
		
//		public Trackingresult(int id, Question question, Result result, int choice, int answer) 
		for (int i = 0; i < number.intValue(); i++) {
			Integer q = 0;
			Integer c = 0;
			q = Integer.parseInt(request.getParameter("question_" + i));
			
			if (request.getParameter("answerid_" + i) == null) {
				c = 0;
			} else {
				c = Integer.parseInt(request.getParameter("answerid_" + i));
			}

			Trackingresult tr = new Trackingresult();
			tr.setQuestion(questionService.findQuestionByID(q));
			tr.setResult(result);
			tr.setChoice(c);
//			neu la string setChoice ("")
			tr.setAnswer(answerService.findTrueAnswerByQuestionID(q).getId());
			
			resultService.createTrackingResult(tr);
		}
		
		return "redirect:/result/listResultByUser.html";
	}

	
	
	
	
	
	//===============================================================
	
	
	
	
	
	
	
//		modelMap.put("quiz", quizService.generateRandomQuiz());


	/**
	 * @param id = result ID
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "review/{id}", method = RequestMethod.GET)
	public String review(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		
		List<Trackingresult> listtr = resultService.LoadTrackingResultByResultID(id);
		
		List<Answer> listChoiceAnswer = new ArrayList<>() ;
		List<Answer> listTrueAnswer = new ArrayList<>() ;
		
		for (int i = 0; i < listtr.size(); i++) {
			listChoiceAnswer.add(answerService.findAnswerByID(listtr.get(i).getChoice()));
			listTrueAnswer.add(answerService.findAnswerByID(listtr.get(i).getAnswer()));
		}
		
		int score = resultService.LoadResultByResultID(id).getScore();
		
		System.out.println("======================================");
		System.out.println("List<Trackingresult> = " + listtr.size());
		System.out.println("======================================");
		
		
		modelMap.put("score", score);
		modelMap.put("listtr", listtr);
		modelMap.put("listChoiceAnswer", listChoiceAnswer);
		modelMap.put("listTrueAnswer", listTrueAnswer);
		
		return "reviewResult";
	}


}
