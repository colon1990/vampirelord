package quiz.dao;

import java.util.List;

import quiz.entities.UserRole;
import quiz.entities.Users;

public interface AccountDAO {

	public List<Users> ListAccount();

	public void createAccount(Users user);

	public void deleteAccount(Users id);

	public void updateAccount(Users user);

	public Users findAccountByID(int id);

	public List<UserRole> listRole();

	public Integer findIDByUsername(String username);

	public Users loadUserByUsername(String username);

}
