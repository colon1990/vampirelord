package quiz.dao;

import java.util.List;

import quiz.entities.Answer;
import quiz.entities.Question;

public interface AnswerDAO {

	public List<Answer> ListAnswer();

	public void createAnswer(Answer a);

	public void updateAnswer(Answer a);

	public void deleteAnswer(Answer a);

	public Answer findAnswerByID(int id);

	public List<Answer> findAnswerByQuesntionID(Integer qid);

	public List<Answer> ListAnswerByQuesntionID(Question q);

	public Answer findTrueAnswerByQuestionID(Integer qid);

}
