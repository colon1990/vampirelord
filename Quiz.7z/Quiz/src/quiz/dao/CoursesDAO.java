package quiz.dao;

import java.util.List;

import quiz.entities.Courses;

public interface CoursesDAO {
	public List<Courses> ListCourses();

	public void createCourses(Courses c);

	public void updateCourses(Courses c);

	public void deleteCourses(Courses c);

	public Courses findCoursesByID(int i);
}
