package quiz.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import quiz.entities.Courses;

@Repository(value = "coursesDAO")
public class CoursesDAOImpl implements CoursesDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@SuppressWarnings("unchecked")
	public List<Courses> ListCourses() {
		return sessionFactory.getCurrentSession().createCriteria(Courses.class).list();
	}

	@Override
	public void createCourses(Courses c) {
		sessionFactory.getCurrentSession().persist(c);
	}

	@Override
	public void updateCourses(Courses c) {
		sessionFactory.getCurrentSession().merge(c);

	}

	@Override
	public void deleteCourses(Courses c) {
		sessionFactory.getCurrentSession().delete(c);
	}

	@Override
	public Courses findCoursesByID(int id) {
		return (Courses) sessionFactory.getCurrentSession().get(Courses.class, id);
	}

}
