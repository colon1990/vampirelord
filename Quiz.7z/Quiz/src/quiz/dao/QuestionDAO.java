package quiz.dao;

import java.util.List;

import quiz.entities.Question;
import quiz.entities.Questionlevel;

/**
 * @author dhonghai
 *
 */
public interface QuestionDAO {

	public List<Question> ListQuestion();

	public void createQuestion(Question q);

	public void updateQuestion(Question q);

	public void deleteQuestion(Question q);

	public Question findQuestionByID(Integer id);
	// public Question findQuestionByUsername(String username);

	public List<Questionlevel> ListAllQuestionLevel();

	public List<Question> listQuestionByCourseID(int cid);

	public List<Question> listQuestionByExamID(int eid);
}
