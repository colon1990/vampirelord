package quiz.dao;

import java.util.List;

import quiz.entities.Courses;
import quiz.entities.Exam;
import quiz.entities.Examitems;
import quiz.entities.Question;

public interface QuizDAO {
	public List<Question> generateQuiz();

	// String getScrore();
	public List<Exam> ListAllExam();

	public List<Exam> ListExamByCoursesID(Integer id);

	public List<Examitems> loadExamItemByExamID(Integer id);

	public List<Question> loadQuestionFromExamID(Integer id);
}
