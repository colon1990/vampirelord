package quiz.model;

public class FilterResult {
	public int question[];
	public int answer[];

	public FilterResult(int[] question, int[] answer) {
		super();
		this.question = question;
		this.answer = answer;
	}

	public int[] getQuestion() {
		return question;
	}

	public int[] getAnswer() {
		return answer;
	}

	public void setQuestion(int[] question) {
		this.question = question;
	}

	public void setAnswer(int[] answer) {
		this.answer = answer;
	}

}
