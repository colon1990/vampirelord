package quiz.model;

import java.util.List;

import quiz.entities.Answer;
import quiz.entities.Question;

public class QuizModelBegin {

	private Question question;
	private List<Answer> answers;

	public QuizModelBegin() {
	}

	public QuizModelBegin(Question question, List<Answer> answers) {
		super();
		this.question = question;
		this.answers = answers;
	}

	public Question getQuestion() {
		return question;
	}

	public List<Answer> getAnswers() {
		return answers;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}
}
