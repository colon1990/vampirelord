package quiz.model;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;

public class Repeated {
    public static void main( String  [] args ) {
        Collection listOne = new ArrayList(Arrays.asList("milan","dingo", "elpha", "hafil", "meat", "iga", "neeta.peeta"));
        Collection listTwo = new ArrayList(Arrays.asList(        "dingo",          "hafil",         "iga"));// , "binga", "mike"

//        listOne.retainAll( listTwo ); 
        listOne.contains(listTwo);
        System.out.println( listOne );
    }
}