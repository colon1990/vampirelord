package quiz.model;

public class testa {
	public static void main(String[] args) {

		int a = 5;
		int b = 4;
		int c = 3;
		int max = (c > b) ? a : b;	
		
		System.out.println("max = " + max);
		

	}
}
