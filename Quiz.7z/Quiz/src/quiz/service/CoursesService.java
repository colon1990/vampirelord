package quiz.service;

import java.util.List;

import quiz.entities.Courses;

public interface CoursesService {
	public List<Courses> ListCourses();

	public void createCourses(Courses c);

	public void updateCourses(Courses c);

	public void deleteCourses(Courses c);

	public Courses findCoursesByID(int i);
}
