package quiz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import quiz.dao.CoursesDAO;
import quiz.entities.Courses;

@Service(value = "coursesService")
@Transactional
public class CoursesServiceImpl implements CoursesService {
	@Autowired
	private CoursesDAO coursesDAO ;

	@Override
	public List<Courses> ListCourses() {
		return coursesDAO.ListCourses();
	}

	@Override
	public void createCourses(Courses c) {
		coursesDAO.createCourses(c);
	}

	@Override
	public void updateCourses(Courses c) {
		coursesDAO.updateCourses(c);
	}

	@Override
	public void deleteCourses(Courses c) {
		coursesDAO.deleteCourses(c);
	}

	@Override
	public Courses findCoursesByID(int i) {
		return coursesDAO.findCoursesByID(i);
	}

}
