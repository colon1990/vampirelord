package quiz.service;

import java.util.List;

import quiz.entities.Question;
import quiz.entities.Questionlevel;

/**
 * @author dhonghai
 *
 */
public interface QuestionService {
	public List<Question> ListQuestion();

	public void createQuestion(Question q);

	public void updateQuestion(Question q);

	public void deleteQuestion(Question q);

	public Question findQuestionByID(Integer i);

	public List<Questionlevel> ListAllQuestionLevel();

	public List<Question> listQuestionByCourseID(int cid);

	public List<Question> listQuestionByExamID(int eid);

}
