package quiz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import quiz.dao.QuestionDAO;
import quiz.entities.Question;
import quiz.entities.Questionlevel;

/**
 * @author dhonghai
 *
 */
@Service(value = "questionService")
@Transactional
public class QuestionServiceImpl implements QuestionService {

	@Autowired
	private QuestionDAO questionDAO;

	@Override
	public List<Question> ListQuestion() {
		return questionDAO.ListQuestion();
	}

	// ======================================================
	public QuestionDAO getQuestionDAO() {
		return questionDAO;
	}

	public void setQuestionDAO(QuestionDAO QuestionDAO) {
		this.questionDAO = QuestionDAO;
	}

	// ======================================================
	@Override
	public void createQuestion(Question c) {
		questionDAO.createQuestion(c);
	}

	@Override
	public void updateQuestion(Question c) {
		questionDAO.updateQuestion(c);
	}

	@Override
	public void deleteQuestion(Question c) {
		questionDAO.deleteQuestion(c);
	}

	@Override
	public Question findQuestionByID(Integer id) {
		return questionDAO.findQuestionByID(id);
	}
	//
	// @Override
	// public Question findQuestionByUsername(int i) {
	// return null;
	// }

	@Override
	public List<Questionlevel> ListAllQuestionLevel() {
		return questionDAO.ListAllQuestionLevel();
	}

	@Override
	public List<Question> listQuestionByCourseID(int cid) {
		return questionDAO.listQuestionByCourseID(cid);
	}

	@Override
	public List<Question> listQuestionByExamID(int eid) {
		return questionDAO.listQuestionByExamID (eid);
	}

}
