package quiz.service;

import java.util.List;

import quiz.entities.Exam;
import quiz.entities.Examitems;
import quiz.entities.Question;

public interface QuizService {
	
	public List<Question> generateRandomQuiz();

	public List<Exam> ListAllExam();

	public List<Exam> ListExamByCoursesID(Integer id);

	public List<Examitems> loadExamItemByExamID(Integer id);

	public List<Question> loadQuestionFromExamID(Integer id);

}
