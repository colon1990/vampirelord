package quiz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import quiz.dao.QuizDAO;
import quiz.entities.Courses;
import quiz.entities.Exam;
import quiz.entities.Examitems;
import quiz.entities.Question;

@Service(value = "quizService")
@Transactional
public class QuizServiceImpl implements QuizService {

	@Autowired
	private QuizDAO quizDAO;

	@Override
	public List<Question> generateRandomQuiz() {
		return quizDAO.generateQuiz();
	}


	@Override
	public List<Exam> ListAllExam() {
		return quizDAO.ListAllExam();
	}

	@Override
	public List<Exam> ListExamByCoursesID(Integer id) {
		return quizDAO.ListExamByCoursesID(id);
	}


	@Override
	public List<Examitems> loadExamItemByExamID(Integer id) {
		return quizDAO.loadExamItemByExamID(id);
	}


	@Override
	public List<Question> loadQuestionFromExamID(Integer id) {
		// TODO Auto-generated method stub
		return quizDAO.loadQuestionFromExamID(id) ;
	}

}
