package quiz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import quiz.dao.ResultDAO;
import quiz.entities.Result;
import quiz.entities.Trackingresult;

@Service(value = "resultService")
@Transactional
public class ResultServiceImpl implements ResultService {

	@Autowired
	private ResultDAO resultDAO;

	@Override
	public List<Result> listAllResult() {
		return resultDAO.listAllResult();
	}

	@Override
	public List<Result> ListAllResultByUserID(int id) {
		return resultDAO.ListAllResultByUserID(id) ;
	}

	@Override
	public void createResult(Result result) {
		 resultDAO.createResult(result);
	}

	@Override
	public List<Trackingresult> LoadTrackingResultByResultID(Integer id) {
		return  resultDAO.LoadTrackingResultByResultID(id);
	}

	@Override
	public void createTrackingResult(Trackingresult tr) {
		  resultDAO.createTrackingResult(tr); 		
	}

	@Override
	public Result LoadResultByResultID(int rid) {
		return   resultDAO.LoadResultByResultID (rid) ;
	}

}
